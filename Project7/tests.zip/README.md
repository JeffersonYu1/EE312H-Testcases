# README

## How to use:
* Download the zip file and extract all the contents into your source directory for lab7. 
* Run `bringup.sh` first in order to patch main with changes.
* Run the binary (or zip and use the sample grader)
* Run `teardown.sh` to restore main.cpp to its original state.
